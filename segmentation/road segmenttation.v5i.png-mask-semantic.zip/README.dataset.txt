# road segmenttation > 2023-06-12 5:58pm
https://universe.roboflow.com/zwdyolov5/road-segmenttation

Provided by a Roboflow user
License: CC BY 4.0

